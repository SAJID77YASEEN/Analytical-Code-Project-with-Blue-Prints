<?php

namespace Tests\Feature;

use App\Models\User;
use App\Models\Event;
use App\Models\Booking;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Queue;
use App\Jobs\SendBookingConfirmation;
use Tests\TestCase;

class BookingTest extends TestCase
{
    use RefreshDatabase, WithFaker;

    protected $user;
    protected $event;

    protected function setUp(): void
    {
        parent::setUp();

        $this->user = User::factory()->create();
        $this->event = Event::factory()->create([
            'capacity' => 10,
            'date' => now()->addDays(7),
            'price' => 50.00,
        ]);
    }

    /** @test */
    public function authenticated_user_can_book_event()
    {
        $this->actingAs($this->user);

        $response = $this->post(route('bookings.store', $this->event), [
            'quantity' => 2,
            'notes' => 'Test booking',
        ]);

        $response->assertRedirect();
        $this->assertDatabaseHas('bookings', [
            'user_id' => $this->user->id,
            'event_id' => $this->event->id,
            'quantity' => 2,
            'total_amount' => 100.00,
            'status' => 'confirmed',
        ]);
    }

    /** @test */
    public function cannot_book_when_event_is_fully_booked()
    {
        $this->actingAs($this->user);

        // Book all available tickets
        Booking::factory()->create([
            'event_id' => $this->event->id,
            'quantity' => 10,
            'status' => 'confirmed',
        ]);

        $response = $this->post(route('bookings.store', $this->event), [
            'quantity' => 1,
        ]);

        $response->assertRedirect();
        $response->assertSessionHas('error');

        $this->assertDatabaseMissing('bookings', [
            'user_id' => $this->user->id,
            'event_id' => $this->event->id,
        ]);
    }

    /** @test */
    public function cannot_book_more_tickets_than_available()
    {
        $this->actingAs($this->user);

        // Book 8 tickets, leaving 2 available
        Booking::factory()->create([
            'event_id' => $this->event->id,
            'quantity' => 8,
            'status' => 'confirmed',
        ]);

        $response = $this->post(route('bookings.store', $this->event), [
            'quantity' => 5, // Try to book 5 when only 2 available
        ]);

        $response->assertRedirect();
        $response->assertSessionHas('error');

        $this->assertDatabaseMissing('bookings', [
            'user_id' => $this->user->id,
            'event_id' => $this->event->id,
        ]);
    }

    /** @test */
    public function cannot_book_past_event()
    {
        $this->actingAs($this->user);

        $pastEvent = Event::factory()->create([
            'date' => now()->subDays(1),
            'capacity' => 10,
        ]);

        $response = $this->post(route('bookings.store', $pastEvent), [
            'quantity' => 1,
        ]);

        $response->assertRedirect();
        $response->assertSessionHas('error');
    }

    /** @test */
    public function booking_confirmation_email_is_queued()
    {
        Queue::fake();
        $this->actingAs($this->user);

        $this->post(route('bookings.store', $this->event), [
            'quantity' => 1,
        ]);

        Queue::assertPushed(SendBookingConfirmation::class);
    }

    /** @test */
    public function user_can_cancel_booking()
    {
        $this->actingAs($this->user);

        $booking = Booking::factory()->create([
            'user_id' => $this->user->id,
            'event_id' => $this->event->id,
            'status' => 'confirmed',
        ]);

        $response = $this->patch(route('bookings.cancel', $booking));

        $response->assertRedirect();
        $this->assertDatabaseHas('bookings', [
            'id' => $booking->id,
            'status' => 'cancelled',
        ]);
    }

    /** @test */
    public function cannot_cancel_booking_24_hours_before_event()
    {
        $this->actingAs($this->user);

        $soonEvent = Event::factory()->create([
            'date' => now()->addHours(12), // Less than 24 hours
        ]);

        $booking = Booking::factory()->create([
            'user_id' => $this->user->id,
            'event_id' => $soonEvent->id,
            'status' => 'confirmed',
        ]);

        $response = $this->patch(route('bookings.cancel', $booking));

        $response->assertRedirect();
        $response->assertSessionHas('error');
        $this->assertDatabaseHas('bookings', [
            'id' => $booking->id,
            'status' => 'confirmed', // Status should remain unchanged
        ]);
    }

    /** @test */
    public function concurrent_bookings_prevent_overbooking()
    {
        // This test simulates concurrent bookings to ensure no overbooking occurs
        $user1 = User::factory()->create();
        $user2 = User::factory()->create();

        $event = Event::factory()->create(['capacity' => 1]); // Only 1 ticket available

        $this->actingAs($user1);
        $response1 = $this->post(route('bookings.store', $event), ['quantity' => 1]);

        $this->actingAs($user2);
        $response2 = $this->post(route('bookings.store', $event), ['quantity' => 1]);

        // One should succeed, one should fail
        $confirmedBookings = Booking::where('event_id', $event->id)
            ->where('status', 'confirmed')
            ->count();

        $this->assertEquals(1, $confirmedBookings);
    }

    /** @test */
    public function booking_validation_rules_work()
    {
        $this->actingAs($this->user);

        $response = $this->post(route('bookings.store', $this->event), [
            'quantity' => 0, // Invalid quantity
        ]);

        $response->assertSessionHasErrors('quantity');
    }

    /** @test */
    public function user_can_view_their_bookings()
    {
        $this->actingAs($this->user);

        $booking = Booking::factory()->create([
            'user_id' => $this->user->id,
            'event_id' => $this->event->id,
        ]);

        $response = $this->get(route('bookings.index'));

        $response->assertOk();
        $response->assertSee($booking->booking_reference);
        $response->assertSee($this->event->title);
    }
}
