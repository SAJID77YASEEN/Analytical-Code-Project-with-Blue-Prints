<?php

namespace Tests\Feature;

use App\Models\User;
use App\Models\Event;
use App\Models\Booking;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Tests\TestCase;

class EventTest extends TestCase
{
    use RefreshDatabase, WithFaker;

    protected $user;

    protected function setUp(): void
    {
        parent::setUp();
        $this->user = User::factory()->create(['role' => 'admin']);
    }

    /** @test */
    public function can_view_events_index()
    {
        Event::factory()->count(5)->create(['status' => 'published']);

        $response = $this->get(route('events.index'));

        $response->assertOk();
        $response->assertViewIs('events.index');
    }

    /** @test */
    public function can_search_events()
    {
        Event::factory()->create([
            'title' => 'Laravel Conference',
            'status' => 'published',
            'date' => now()->addDays(5),
        ]);

        Event::factory()->create([
            'title' => 'Vue.js Workshop',
            'status' => 'published',
            'date' => now()->addDays(10),
        ]);

        $response = $this->get(route('events.index', ['search' => 'Laravel']));

        $response->assertOk();
        $response->assertSee('Laravel Conference');
        $response->assertDontSee('Vue.js Workshop');
    }

    /** @test */
    public function can_filter_events_by_venue()
    {
        Event::factory()->create([
            'title' => 'Event 1',
            'venue' => 'Conference Center',
            'status' => 'published',
            'date' => now()->addDays(5),
        ]);

        Event::factory()->create([
            'title' => 'Event 2',
            'venue' => 'Hotel Ballroom',
            'status' => 'published',
            'date' => now()->addDays(10),
        ]);

        $response = $this->get(route('events.index', ['venue' => 'Conference']));

        $response->assertOk();
        $response->assertSee('Event 1');
        $response->assertDontSee('Event 2');
    }

    /** @test */
    public function can_filter_events_by_date_range()
    {
        Event::factory()->create([
            'title' => 'Early Event',
            'date' => now()->addDays(2),
            'status' => 'published',
        ]);

        Event::factory()->create([
            'title' => 'Later Event',
            'date' => now()->addDays(20),
            'status' => 'published',
        ]);

        $response = $this->get(route('events.index', [
            'date_from' => now()->addDays(1)->toDateString(),
            'date_to' => now()->addDays(10)->toDateString(),
        ]));

        $response->assertOk();
        $response->assertSee('Early Event');
        $response->assertDontSee('Later Event');
    }

    /** @test */
    public function authenticated_admin_can_create_event()
    {
        $this->actingAs($this->user);

        $eventData = [
            'title' => 'Test Event',
            'description' => 'This is a test event',
            'venue' => 'Test Venue',
            'capacity' => 100,
            'date' => now()->addDays(30)->toDateString(),
            'start_time' => '09:00',
            'end_time' => '17:00',
            'price' => 50.00,
        ];

        $response = $this->post(route('events.store'), $eventData);

        $response->assertRedirect();
        $this->assertDatabaseHas('events', [
            'title' => 'Test Event',
            'venue' => 'Test Venue',
            'capacity' => 100,
            'price' => 50.00,
            'user_id' => $this->user->id,
        ]);
    }

    /** @test */
    public function can_create_event_with_image()
    {
        Storage::fake('public');
        $this->actingAs($this->user);

        $file = UploadedFile::fake()->image('event.jpg');

        $eventData = [
            'title' => 'Test Event with Image',
            'description' => 'This is a test event',
            'venue' => 'Test Venue',
            'capacity' => 100,
            'date' => now()->addDays(30)->toDateString(),
            'start_time' => '09:00',
            'end_time' => '17:00',
            'price' => 50.00,
            'image' => $file,
        ];

        $response = $this->post(route('events.store'), $eventData);

        $response->assertRedirect();
        $this->assertDatabaseHas('events', ['title' => 'Test Event with Image']);

        $event = Event::where('title', 'Test Event with Image')->first();
        $this->assertNotNull($event->image);
        Storage::disk('public')->assertExists($event->image);
    }

    /** @test */
    public function event_validation_rules_work()
    {
        $this->actingAs($this->user);

        $response = $this->post(route('events.store'), [
            'title' => '', // Required field
            'capacity' => 0, // Min 1
            'date' => now()->subDay()->toDateString(), // Must be future
        ]);

        $response->assertSessionHasErrors(['title', 'capacity', 'date']);
    }

    /** @test */
    public function can_view_single_event()
    {
        $event = Event::factory()->create(['status' => 'published']);

        $response = $this->get(route('events.show', $event));

        $response->assertOk();
        $response->assertSee($event->title);
        $response->assertSee($event->description);
    }

    /** @test */
    public function can_update_event()
    {
        $this->actingAs($this->user);

        $event = Event::factory()->create(['user_id' => $this->user->id]);

        $updateData = [
            'title' => 'Updated Event Title',
            'description' => $event->description,
            'venue' => $event->venue,
            'capacity' => $event->capacity,
            'date' => now()->addDays(30)->toDateString(),
            'start_time' => $event->start_time->format('H:i'),
            'end_time' => $event->end_time->format('H:i'),
            'price' => $event->price,
        ];

        $response = $this->put(route('events.update', $event), $updateData);

        $response->assertRedirect();
        $this->assertDatabaseHas('events', [
            'id' => $event->id,
            'title' => 'Updated Event Title',
        ]);
    }

    /** @test */
    public function cannot_delete_event_with_confirmed_bookings()
    {
        $this->actingAs($this->user);

        $event = Event::factory()->create(['user_id' => $this->user->id]);

        Booking::factory()->create([
            'event_id' => $event->id,
            'status' => 'confirmed',
        ]);

        $response = $this->delete(route('events.destroy', $event));

        $response->assertRedirect();
        $response->assertSessionHas('error');
        $this->assertDatabaseHas('events', ['id' => $event->id]);
    }

    /** @test */
    public function can_get_event_analytics()
    {
        $this->actingAs($this->user);

        $event = Event::factory()->create(['user_id' => $this->user->id]);

        Booking::factory()->count(5)->create([
            'event_id' => $event->id,
            'status' => 'confirmed',
            'total_amount' => 100.00,
        ]);

        $response = $this->get(route('events.analytics', $event));

        $response->assertOk();
        $response->assertJson([
            'total_bookings' => 5,
            'confirmed_bookings' => 5,
            'total_revenue' => 500.00,
        ]);
    }
}
