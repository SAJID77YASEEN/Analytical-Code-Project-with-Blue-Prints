<?php

namespace Tests\Unit;

use App\Models\User;
use App\Models\Event;
use App\Models\Booking;
use App\Services\BookingService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Cache;
use Tests\TestCase;

class BookingServiceTest extends TestCase
{
    use RefreshDatabase;

    protected $bookingService;
    protected $user;
    protected $event;

    protected function setUp(): void
    {
        parent::setUp();

        $this->bookingService = new BookingService();
        $this->user = User::factory()->create();
        $this->event = Event::factory()->create([
            'capacity' => 100,
            'date' => now()->addDays(7),
            'price' => 25.00,
        ]);
    }

    /** @test */
    public function can_get_top_events_by_bookings()
    {
        // Create events with different booking counts
        $event1 = Event::factory()->create(['title' => 'Popular Event']);
        $event2 = Event::factory()->create(['title' => 'Less Popular Event']);

        // Create more bookings for event1
        Booking::factory()->count(10)->create([
            'event_id' => $event1->id,
            'status' => 'confirmed',
            'created_at' => now()->subDays(15),
        ]);

        Booking::factory()->count(5)->create([
            'event_id' => $event2->id,
            'status' => 'confirmed',
            'created_at' => now()->subDays(10),
        ]);

        $topEvents = $this->bookingService->getTopEventsByBookings(30);

        $this->assertCount(2, $topEvents);
        $this->assertEquals('Popular Event', $topEvents->first()->title);
        $this->assertEquals(10, $topEvents->first()->total_bookings);
    }

    /** @test */
    public function can_get_active_users()
    {
        $activeUser = User::factory()->create();
        $inactiveUser = User::factory()->create();

        // Create bookings for different events for active user
        $events = Event::factory()->count(5)->create();
        foreach ($events as $event) {
            Booking::factory()->create([
                'user_id' => $activeUser->id,
                'event_id' => $event->id,
                'status' => 'confirmed',
                'created_at' => now()->subDays(20),
            ]);
        }

        // Create only 2 bookings for inactive user
        Booking::factory()->count(2)->create([
            'user_id' => $inactiveUser->id,
            'status' => 'confirmed',
            'created_at' => now()->subDays(15),
        ]);

        $activeUsers = $this->bookingService->getActiveUsers(3);

        $this->assertCount(1, $activeUsers);
        $this->assertEquals($activeUser->id, $activeUsers->first()->id);
        $this->assertEquals(5, $activeUsers->first()->events_booked);
    }

    /** @test */
    public function can_get_event_occupancy_stats()
    {
        $event1 = Event::factory()->create(['capacity' => 100]);
        $event2 = Event::factory()->create(['capacity' => 50]);

        // Book 75% of event1
        Booking::factory()->create([
            'event_id' => $event1->id,
            'quantity' => 75,
            'status' => 'confirmed',
        ]);

        // Book 50% of event2
        Booking::factory()->create([
            'event_id' => $event2->id,
            'quantity' => 25,
            'status' => 'confirmed',
        ]);

        $occupancyStats = $this->bookingService->getEventOccupancyStats();

        $event1Stats = $occupancyStats->where('id', $event1->id)->first();
        $event2Stats = $occupancyStats->where('id', $event2->id)->first();

        $this->assertEquals(75.0, $event1Stats->occupancy_percentage);
        $this->assertEquals(50.0, $event2Stats->occupancy_percentage);
    }

    /** @test */
    public function can_create_booking_with_transaction()
    {
        $booking = $this->bookingService->createBooking(
            $this->event->id,
            $this->user->id,
            2,
            'Test booking'
        );

        $this->assertDatabaseHas('bookings', [
            'id' => $booking->id,
            'user_id' => $this->user->id,
            'event_id' => $this->event->id,
            'quantity' => 2,
            'total_amount' => 50.00,
            'status' => 'confirmed',
        ]);
    }

    /** @test */
    public function cannot_create_booking_for_past_event()
    {
        $pastEvent = Event::factory()->create(['date' => now()->subDay()]);

        $this->expectException(\Exception::class);
        $this->expectExceptionMessage('Cannot book tickets for past events.');

        $this->bookingService->createBooking($pastEvent->id, $this->user->id, 1);
    }

    /** @test */
    public function cannot_create_booking_when_insufficient_tickets()
    {
        // Book all but 1 ticket
        Booking::factory()->create([
            'event_id' => $this->event->id,
            'quantity' => 99,
            'status' => 'confirmed',
        ]);

        $this->expectException(\Exception::class);
        $this->expectExceptionMessage('Not enough tickets available');

        $this->bookingService->createBooking($this->event->id, $this->user->id, 5);
    }

    /** @test */
    public function can_cancel_booking()
    {
        $booking = Booking::factory()->create([
            'user_id' => $this->user->id,
            'event_id' => $this->event->id,
            'status' => 'confirmed',
        ]);

        $cancelledBooking = $this->bookingService->cancelBooking($booking->id);

        $this->assertEquals('cancelled', $cancelledBooking->status);
        $this->assertDatabaseHas('bookings', [
            'id' => $booking->id,
            'status' => 'cancelled',
        ]);
    }

    /** @test */
    public function can_get_booking_analytics()
    {
        // Create test data
        Booking::factory()->count(5)->create([
            'status' => 'confirmed',
            'total_amount' => 100.00,
            'created_at' => now()->subDays(10),
        ]);

        Booking::factory()->count(2)->create([
            'status' => 'cancelled',
            'created_at' => now()->subDays(5),
        ]);

        $analytics = $this->bookingService->getBookingAnalytics(
            now()->subDays(30),
            now()
        );

        $this->assertEquals(7, $analytics['total_bookings']);
        $this->assertEquals(5, $analytics['confirmed_bookings']);
        $this->assertEquals(2, $analytics['cancelled_bookings']);
        $this->assertEquals(500.00, $analytics['total_revenue']);
        $this->assertEquals(100.00, $analytics['average_booking_value']);
    }

    /** @test */
    public function caching_works_for_analytics_methods()
    {
        Cache::shouldReceive('remember')
            ->once()
            ->andReturn(collect());

        $this->bookingService->getTopEventsByBookings(30);
    }
}
