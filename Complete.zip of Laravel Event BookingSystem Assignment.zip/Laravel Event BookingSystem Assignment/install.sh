#!/bin/bash

# Event Booking System - Installation Script
echo "🎫 Setting up Event Booking System..."

# Check if composer is installed
if ! command -v composer &> /dev/null; then
    echo "❌ Composer is not installed. Please install composer first."
    exit 1
fi

# Check if PHP is installed
if ! command -v php &> /dev/null; then
    echo "❌ PHP is not installed. Please install PHP 8.1+ first."
    exit 1
fi

# Install dependencies
echo "📦 Installing composer dependencies..."
composer install

# Copy environment file
if [ ! -f .env ]; then
    echo "📝 Creating environment file..."
    cp .env.example .env

    # Generate application key
    php artisan key:generate

    echo "⚠️  Please configure your database settings in .env file:"
    echo "   DB_DATABASE=event_booking_system"
    echo "   DB_USERNAME=your_username" 
    echo "   DB_PASSWORD=your_password"
    echo ""
    echo "📧 Configure email settings for notifications:"
    echo "   MAIL_HOST=your_smtp_host"
    echo "   MAIL_USERNAME=your_smtp_username"
    echo "   MAIL_PASSWORD=your_smtp_password"
    echo ""
    echo "🔐 Configure social login (optional):"
    echo "   GOOGLE_CLIENT_ID=your_google_client_id"
    echo "   GOOGLE_CLIENT_SECRET=your_google_client_secret"
    echo "   GITHUB_CLIENT_ID=your_github_client_id"
    echo "   GITHUB_CLIENT_SECRET=your_github_client_secret"
    echo ""

    read -p "Press Enter after configuring .env file..."
fi

# Create database if it doesn't exist
echo "🗄️  Setting up database..."
php artisan migrate --force

# Seed the database
echo "🌱 Seeding database with sample data..."
php artisan db:seed --force

# Create storage link
echo "🔗 Creating storage link..."
php artisan storage:link

# Cache configuration
echo "⚡ Optimizing application..."
php artisan config:cache
php artisan route:cache
php artisan view:cache

# Set permissions
echo "🔐 Setting permissions..."
chmod -R 755 storage
chmod -R 755 bootstrap/cache

echo "✅ Installation completed successfully!"
echo ""
echo "🚀 To start the application:"
echo "   php artisan serve"
echo ""
echo "👥 Test credentials:"
echo "   Email: admin@example.com"
echo "   Password: password"
echo ""
echo "🔄 To start queue worker:"
echo "   php artisan queue:work"
echo ""
echo "📊 Access the application at: http://localhost:8000"
