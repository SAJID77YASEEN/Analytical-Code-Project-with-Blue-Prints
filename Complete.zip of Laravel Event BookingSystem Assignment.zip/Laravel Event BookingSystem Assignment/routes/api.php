<?php

use App\Http\Controllers\EventController;
use App\Http\Controllers\BookingController;
use App\Services\BookingService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

// Public API Routes
Route::prefix('v1')->group(function () {
    // Events API
    Route::get('/events', [EventController::class, 'index'])->name('api.events.index');
    Route::get('/events/{event}', [EventController::class, 'show'])->name('api.events.show');
    Route::get('/events/{event}/analytics', [EventController::class, 'analytics'])->name('api.events.analytics');

    // Protected API Routes
    Route::middleware('auth:sanctum')->group(function () {
        // Booking API
        Route::get('/bookings', [BookingController::class, 'index'])->name('api.bookings.index');
        Route::post('/events/{event}/book', [BookingController::class, 'store'])->name('api.bookings.store');
        Route::get('/bookings/{booking}', [BookingController::class, 'show'])->name('api.bookings.show');
        Route::patch('/bookings/{booking}/cancel', [BookingController::class, 'cancel'])->name('api.bookings.cancel');

        // Analytics API
        Route::get('/analytics/top-events', function (BookingService $service) {
            return response()->json($service->getTopEventsByBookings());
        })->name('api.analytics.top-events');

        Route::get('/analytics/active-users', function (BookingService $service) {
            return response()->json($service->getActiveUsers());
        })->name('api.analytics.active-users');

        Route::get('/analytics/occupancy', function (BookingService $service) {
            return response()->json($service->getEventOccupancyStats());
        })->name('api.analytics.occupancy');
    });
});
