<?php

namespace Database\Seeders;

use App\Models\User;
use App\Models\Event;
use App\Models\Booking;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // Create admin user
        $admin = User::create([
            'name' => 'Admin User',
            'email' => 'admin@example.com',
            'password' => Hash::make('password'),
            'role' => 'admin',
            'email_verified_at' => now(),
        ]);

        // Create regular users
        $users = User::factory()->count(50)->create();

        // Create events
        $events = Event::factory()->count(20)->create([
            'user_id' => $admin->id,
        ]);

        // Create bookings for the past month
        foreach ($events as $event) {
            // Random number of bookings per event
            $bookingCount = rand(5, 15);

            for ($i = 0; $i < $bookingCount; $i++) {
                $user = $users->random();
                $quantity = rand(1, 4);

                // Some bookings from last month, some recent
                $createdAt = rand(0, 1) ? now()->subDays(rand(1, 30)) : now()->subDays(rand(1, 7));

                Booking::create([
                    'user_id' => $user->id,
                    'event_id' => $event->id,
                    'quantity' => $quantity,
                    'total_amount' => $event->price * $quantity,
                    'status' => rand(0, 9) < 8 ? 'confirmed' : 'cancelled', // 80% confirmed
                    'created_at' => $createdAt,
                    'updated_at' => $createdAt,
                ]);
            }
        }

        $this->command->info('Database seeded successfully!');
        $this->command->info('Admin credentials: admin@example.com / password');
    }
}
