<?php

namespace Database\Seeders;

use App\Models\Event;
use App\Models\User;
use Illuminate\Database\Seeder;

class EventSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $admin = User::where('email', 'admin@example.com')->first();

        if (!$admin) {
            $this->command->error('Admin user not found. Please run DatabaseSeeder first.');
            return;
        }

        $eventData = [
            [
                'title' => 'Laravel Conference 2024',
                'description' => 'Join us for the biggest Laravel event of the year! Learn from industry experts and network with fellow developers.',
                'venue' => 'Grand Convention Center',
                'capacity' => 500,
                'date' => now()->addDays(30),
                'start_time' => '09:00:00',
                'end_time' => '18:00:00',
                'price' => 299.00,
            ],
            [
                'title' => 'PHP Workshop - Advanced Concepts',
                'description' => 'Dive deep into advanced PHP concepts including design patterns, performance optimization, and modern PHP features.',
                'venue' => 'Tech Hub Downtown',
                'capacity' => 50,
                'date' => now()->addDays(15),
                'start_time' => '10:00:00',
                'end_time' => '16:00:00',
                'price' => 149.00,
            ],
            [
                'title' => 'Startup Pitch Night',
                'description' => 'Watch promising startups pitch their ideas to a panel of investors and industry experts.',
                'venue' => 'Innovation Center',
                'capacity' => 200,
                'date' => now()->addDays(45),
                'start_time' => '19:00:00',
                'end_time' => '22:00:00',
                'price' => 25.00,
            ],
            [
                'title' => 'Web Development Bootcamp',
                'description' => 'Intensive 2-day bootcamp covering modern web development technologies and best practices.',
                'venue' => 'University Campus',
                'capacity' => 100,
                'date' => now()->addDays(60),
                'start_time' => '09:00:00',
                'end_time' => '17:00:00',
                'price' => 399.00,
            ],
            [
                'title' => 'AI & Machine Learning Summit',
                'description' => 'Explore the latest trends in artificial intelligence and machine learning with leading researchers.',
                'venue' => 'Science Museum',
                'capacity' => 300,
                'date' => now()->addDays(75),
                'start_time' => '08:30:00',
                'end_time' => '18:30:00',
                'price' => 499.00,
            ],
        ];

        foreach ($eventData as $data) {
            Event::create(array_merge($data, ['user_id' => $admin->id]));
        }

        $this->command->info('Sample events created successfully!');
    }
}
