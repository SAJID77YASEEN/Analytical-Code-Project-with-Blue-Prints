# 🎫 Event Booking System - Laravel MySQL

A comprehensive event booking system built with **Laravel 10** and **MySQL** that prevents overbooking, includes social authentication, and provides advanced analytics.

## 🌟 Features Implemented

### ✅ Core Requirements (Must-Have)
- **User Authentication**: Email/password login + social login (Google/GitHub via Socialite)
- **Event Management**: Create, list, search, filter, and paginate events (title, venue, capacity, date)
- **Booking System**: Users can book tickets with **overbooking prevention** using database transactions
- **Advanced Queries**: All required database analytics queries implemented

### ✅ Database Queries (Important)
- **Top 5 events by bookings** in the last 30 days
- **Users who booked >3 events** last month
- **Occupancy percentage** for each event
- Advanced analytics with revenue tracking

### ✅ Bonus Features
- **Redis Caching**: Event listings and analytics are cached
- **Queue System**: Confirmation emails sent via background jobs
- **Comprehensive Testing**: Unit tests for overbooking prevention
- **Database Optimization**: Strategic indexes and query optimization
- **API Endpoints**: RESTful API for mobile/external integration

## 🚀 Quick Start

### Prerequisites
- PHP 8.1+
- MySQL 8.0+
- Redis (for caching and queues)
- Composer

### Installation

```bash
# Clone the repository
git clone <repository-url>
cd event-booking-system

# Install dependencies
composer install

# Environment setup
cp .env.example .env
php artisan key:generate

# Configure your database in .env
DB_DATABASE=event_booking_system
DB_USERNAME=your_username
DB_PASSWORD=your_password

# Configure Redis
CACHE_DRIVER=redis
QUEUE_CONNECTION=redis

# Configure Social Login (optional)
GOOGLE_CLIENT_ID=your_google_client_id
GOOGLE_CLIENT_SECRET=your_google_client_secret
GITHUB_CLIENT_ID=your_github_client_id  
GITHUB_CLIENT_SECRET=your_github_client_secret

# Run migrations and seeders
php artisan migrate
php artisan db:seed

# Start the application
php artisan serve

# Start queue worker (in separate terminal)
php artisan queue:work

# Start Redis (in separate terminal)
redis-server
```

### Test Credentials
- **Admin**: admin@example.com / password
- **Users**: Generated via seeders with faker data

## 📊 Database Schema

### Tables Created
- **users** - User authentication with social login fields
- **events** - Event information with capacity tracking
- **bookings** - Booking records with status management
- **password_reset_tokens** - Password reset functionality
- **failed_jobs** - Queue job failure tracking

### Key Indexes (Performance Optimized)
```sql
-- Events table
INDEX idx_events_date_status (date, status)
INDEX idx_events_venue (venue)
INDEX idx_events_capacity (capacity)

-- Bookings table  
INDEX idx_bookings_user_status (user_id, status)
INDEX idx_bookings_event_status (event_id, status)
INDEX idx_bookings_created_at (created_at)
INDEX idx_bookings_complex (event_id, status, quantity)
```

## 🛡️ Overbooking Prevention

**Problem Solved**: Two users booking the last available ticket simultaneously.

**Solution**: Database transactions with row locking
```php
DB::transaction(function () use ($request, $event) {
    // Lock the event row to prevent concurrent access
    $event = Event::lockForUpdate()->findOrFail($event->id);

    // Check availability after locking
    if ($event->available_tickets < $request->quantity) {
        throw new \Exception('Not enough tickets available.');
    }

    // Create booking atomically
    $booking = Booking::create([...]);
});
```

## 📈 Advanced Database Queries

### 1. Top 5 Events by Bookings (Last 30 Days)
```php
Event::select('events.*', DB::raw('COUNT(bookings.id) as total_bookings'))
    ->join('bookings', 'events.id', '=', 'bookings.event_id')
    ->where('bookings.status', 'confirmed')
    ->where('bookings.created_at', '>=', now()->subDays(30))
    ->groupBy('events.id')
    ->orderByDesc('total_bookings')
    ->limit(5)
    ->get();
```

### 2. Active Users (>3 Events Last Month)
```php
User::select('users.*', DB::raw('COUNT(DISTINCT bookings.event_id) as events_booked'))
    ->join('bookings', 'users.id', '=', 'bookings.user_id')
    ->where('bookings.status', 'confirmed')
    ->where('bookings.created_at', '>=', now()->subMonth())
    ->groupBy('users.id')
    ->havingRaw('COUNT(DISTINCT bookings.event_id) > 3')
    ->orderByDesc('events_booked')
    ->get();
```

### 3. Event Occupancy Percentage
```php
Event::select([
    'events.*',
    DB::raw('COALESCE(SUM(CASE WHEN bookings.status = "confirmed" THEN bookings.quantity ELSE 0 END), 0) as booked_tickets'),
    DB::raw('ROUND((COALESCE(SUM(CASE WHEN bookings.status = "confirmed" THEN bookings.quantity ELSE 0 END), 0) / events.capacity) * 100, 2) as occupancy_percentage')
])
->leftJoin('bookings', 'events.id', '=', 'bookings.event_id')
->groupBy('events.id')
->get();
```

## 🔧 API Endpoints

### Public Endpoints
```
GET  /api/v1/events              - List events with filtering
GET  /api/v1/events/{id}         - Get single event
```

### Protected Endpoints (Requires Authentication)
```
POST /api/v1/events/{id}/book    - Book event tickets
GET  /api/v1/bookings            - User's bookings
GET  /api/v1/analytics/top-events - Top events by bookings
GET  /api/v1/analytics/active-users - Active users
GET  /api/v1/analytics/occupancy - Event occupancy stats
```

## 🧪 Testing

### Run All Tests
```bash
php artisan test
```

### Key Test Coverage
- ✅ **Overbooking Prevention**: `cannot_book_when_event_is_fully_booked()`
- ✅ **Concurrent Bookings**: `concurrent_bookings_prevent_overbooking()`
- ✅ **Database Queries**: All analytics queries tested
- ✅ **Authentication**: Social login and regular auth
- ✅ **Validation**: All input validation rules
- ✅ **Email Queues**: Confirmation email jobs

### Critical Test: Overbooking Prevention
```php
public function test_cannot_book_when_full()
{
    // Create event with capacity 1
    $event = Event::factory()->create(['capacity' => 1]);

    // Book the last ticket
    Booking::factory()->create([
        'event_id' => $event->id,
        'quantity' => 1,
        'status' => 'confirmed'
    ]);

    // Attempt to book another ticket
    $response = $this->post(route('bookings.store', $event), [
        'quantity' => 1
    ]);

    // Should fail with error
    $response->assertSessionHas('error');
    $this->assertEquals(1, $event->bookings()->confirmed()->count());
}
```

## ⚡ Performance Optimization

### Caching Strategy
- **Event Listings**: Cached for 5 minutes
- **Analytics Queries**: Cached for 30 minutes
- **Popular Venues**: Cached for 1 hour
- **Occupancy Stats**: Cached for 30 minutes

### Database Optimization
- Strategic indexes on frequently queried columns
- Foreign key constraints for data integrity
- Soft deletes for events (preserves booking history)
- Composite indexes for complex analytics queries

### Queue System
- Email notifications sent asynchronously
- Booking confirmations don't block user interface
- Failed job tracking and retry mechanisms

## 🔐 Security Features

- **Input Validation**: All user inputs validated
- **Authentication**: Laravel Sanctum for API security
- **Authorization**: Policy-based access control
- **CSRF Protection**: Built-in Laravel CSRF tokens
- **SQL Injection Prevention**: Eloquent ORM queries
- **Rate Limiting**: API endpoint rate limiting

## 📱 Social Login Setup

### Google OAuth Setup
1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create new project or select existing
3. Enable Google+ API
4. Create OAuth 2.0 credentials
5. Add authorized redirect URI: `http://your-domain.com/auth/google/callback`
6. Update `.env` with client ID and secret

### GitHub OAuth Setup
1. Go to GitHub Settings > Developer settings > OAuth Apps
2. Create new OAuth App
3. Authorization callback URL: `http://your-domain.com/auth/github/callback`
4. Update `.env` with client ID and secret

## 🏗️ Architecture

```
📁 app/
├── 📁 Http/Controllers/     - Request handling
├── 📁 Models/              - Database models
├── 📁 Services/            - Business logic layer
├── 📁 Jobs/                - Queue jobs
├── 📁 Mail/                - Email templates
└── 📁 Policies/            - Authorization policies

📁 database/
├── 📁 migrations/          - Database schema
├── 📁 seeders/             - Sample data
└── 📁 factories/           - Test data factories

📁 tests/
├── 📁 Feature/             - Integration tests
└── 📁 Unit/                - Unit tests
```

## 🎯 Assignment Requirements Met

| Requirement | Status | Implementation |
|-------------|--------|----------------|
| User login (email/password) | ✅ | Laravel Auth + custom controllers |
| Social login (Google/GitHub) | ✅ | Laravel Socialite integration |
| Events CRUD | ✅ | Full event management system |
| Booking system | ✅ | Atomic transactions prevent overbooking |
| Search & filter | ✅ | Advanced search with caching |
| Top 5 events query | ✅ | Optimized with joins and grouping |
| Active users query | ✅ | Complex aggregation query |
| Occupancy percentage | ✅ | Calculated field with caching |
| Cache event listings | ✅ | Redis caching strategy |
| Queue confirmation email | ✅ | Background job processing |
| Unit tests | ✅ | Comprehensive test suite |
| DB optimization | ✅ | Strategic indexes + explanations |

## 🚀 Deployment

### Production Checklist
- [ ] Configure production database
- [ ] Set up Redis server
- [ ] Configure mail driver (SMTP/SES)
- [ ] Set up queue worker service
- [ ] Configure social login callbacks
- [ ] Enable HTTPS
- [ ] Set up monitoring and logging

### Docker Support (Optional)
```bash
# If using Laravel Sail
./vendor/bin/sail up -d
./vendor/bin/sail artisan migrate
./vendor/bin/sail artisan db:seed
```

## 📧 Contact

For questions or support regarding this Event Booking System implementation, please contact the development team.

---

**Built with ❤️ using Laravel 10, MySQL 8, and Redis**
