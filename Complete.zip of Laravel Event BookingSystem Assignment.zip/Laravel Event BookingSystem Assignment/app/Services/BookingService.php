<?php

namespace App\Services;

use App\Models\Event;
use App\Models\Booking;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Cache;

class BookingService
{
    /**
     * Get top 5 events by bookings in the last 30 days.
     */
    public function getTopEventsByBookings($days = 30)
    {
        return Cache::remember('top_events_' . $days . '_days', 3600, function () use ($days) {
            return Event::select('events.*', DB::raw('COUNT(bookings.id) as total_bookings'))
                ->join('bookings', 'events.id', '=', 'bookings.event_id')
                ->where('bookings.status', 'confirmed')
                ->where('bookings.created_at', '>=', now()->subDays($days))
                ->groupBy('events.id')
                ->orderByDesc('total_bookings')
                ->limit(5)
                ->get();
        });
    }

    /**
     * Get users who booked more than 3 events in the last month.
     */
    public function getActiveUsers($eventCount = 3)
    {
        return Cache::remember('active_users_' . $eventCount, 3600, function () use ($eventCount) {
            return User::select('users.*', DB::raw('COUNT(DISTINCT bookings.event_id) as events_booked'))
                ->join('bookings', 'users.id', '=', 'bookings.user_id')
                ->where('bookings.status', 'confirmed')
                ->where('bookings.created_at', '>=', now()->subMonth())
                ->groupBy('users.id')
                ->havingRaw('COUNT(DISTINCT bookings.event_id) > ?', [$eventCount])
                ->orderByDesc('events_booked')
                ->get();
        });
    }

    /**
     * Get occupancy percentage for each event.
     */
    public function getEventOccupancyStats()
    {
        return Cache::remember('event_occupancy_stats', 1800, function () {
            return Event::select([
                'events.id',
                'events.title',
                'events.venue',
                'events.capacity',
                'events.date',
                DB::raw('COALESCE(SUM(CASE WHEN bookings.status = "confirmed" THEN bookings.quantity ELSE 0 END), 0) as booked_tickets'),
                DB::raw('ROUND(
                    (COALESCE(SUM(CASE WHEN bookings.status = "confirmed" THEN bookings.quantity ELSE 0 END), 0) / events.capacity) * 100, 
                    2
                ) as occupancy_percentage')
            ])
            ->leftJoin('bookings', 'events.id', '=', 'bookings.event_id')
            ->where('events.status', 'published')
            ->groupBy('events.id', 'events.title', 'events.venue', 'events.capacity', 'events.date')
            ->orderBy('events.date', 'desc')
            ->get();
        });
    }

    /**
     * Advanced booking analytics with revenue data.
     */
    public function getBookingAnalytics($startDate = null, $endDate = null)
    {
        $startDate = $startDate ?: now()->subDays(30);
        $endDate = $endDate ?: now();

        return Cache::remember('booking_analytics_' . $startDate->format('Y-m-d') . '_' . $endDate->format('Y-m-d'), 1800, function () use ($startDate, $endDate) {
            return [
                'total_bookings' => Booking::whereBetween('created_at', [$startDate, $endDate])->count(),
                'confirmed_bookings' => Booking::confirmed()->whereBetween('created_at', [$startDate, $endDate])->count(),
                'cancelled_bookings' => Booking::cancelled()->whereBetween('created_at', [$startDate, $endDate])->count(),
                'total_revenue' => Booking::confirmed()->whereBetween('created_at', [$startDate, $endDate])->sum('total_amount'),
                'average_booking_value' => Booking::confirmed()->whereBetween('created_at', [$startDate, $endDate])->avg('total_amount'),
                'unique_users' => Booking::whereBetween('created_at', [$startDate, $endDate])->distinct('user_id')->count('user_id'),
                'popular_events' => $this->getPopularEventsInPeriod($startDate, $endDate),
                'daily_bookings' => $this->getDailyBookingStats($startDate, $endDate),
            ];
        });
    }

    /**
     * Get popular events in a specific period.
     */
    private function getPopularEventsInPeriod($startDate, $endDate)
    {
        return Event::select('events.title', DB::raw('COUNT(bookings.id) as booking_count'))
            ->join('bookings', 'events.id', '=', 'bookings.event_id')
            ->where('bookings.status', 'confirmed')
            ->whereBetween('bookings.created_at', [$startDate, $endDate])
            ->groupBy('events.id', 'events.title')
            ->orderByDesc('booking_count')
            ->limit(10)
            ->get();
    }

    /**
     * Get daily booking statistics.
     */
    private function getDailyBookingStats($startDate, $endDate)
    {
        return Booking::select(
                DB::raw('DATE(created_at) as date'),
                DB::raw('COUNT(*) as total_bookings'),
                DB::raw('SUM(CASE WHEN status = "confirmed" THEN 1 ELSE 0 END) as confirmed_bookings'),
                DB::raw('SUM(CASE WHEN status = "confirmed" THEN total_amount ELSE 0 END) as daily_revenue')
            )
            ->whereBetween('created_at', [$startDate, $endDate])
            ->groupBy(DB::raw('DATE(created_at)'))
            ->orderBy('date')
            ->get();
    }

    /**
     * Create a booking with atomic transaction to prevent overbooking.
     */
    public function createBooking($eventId, $userId, $quantity, $notes = null)
    {
        return DB::transaction(function () use ($eventId, $userId, $quantity, $notes) {
            // Lock the event row to prevent concurrent bookings
            $event = Event::lockForUpdate()->findOrFail($eventId);

            // Check if event is still available
            if ($event->isPast()) {
                throw new \Exception('Cannot book tickets for past events.');
            }

            if ($event->available_tickets < $quantity) {
                throw new \Exception('Not enough tickets available. Only ' . $event->available_tickets . ' tickets left.');
            }

            // Create the booking
            $booking = Booking::create([
                'user_id' => $userId,
                'event_id' => $eventId,
                'quantity' => $quantity,
                'total_amount' => $event->price * $quantity,
                'status' => 'confirmed',
                'notes' => $notes,
                'payment_status' => 'pending',
            ]);

            // Clear related caches
            Cache::forget('event_' . $eventId . '_available_tickets');
            Cache::forget('top_events_30_days');
            Cache::forget('event_occupancy_stats');

            return $booking;
        });
    }

    /**
     * Cancel a booking and update availability.
     */
    public function cancelBooking($bookingId)
    {
        return DB::transaction(function () use ($bookingId) {
            $booking = Booking::lockForUpdate()->findOrFail($bookingId);

            if (!$booking->canBeCancelled()) {
                throw new \Exception('This booking cannot be cancelled.');
            }

            $booking->update(['status' => 'cancelled']);

            // Clear related caches
            Cache::forget('event_' . $booking->event_id . '_available_tickets');
            Cache::forget('event_occupancy_stats');

            return $booking;
        });
    }

    /**
     * Get venue popularity statistics.
     */
    public function getVenueStats()
    {
        return Cache::remember('venue_stats', 3600, function () {
            return Event::select(
                'venue',
                DB::raw('COUNT(*) as total_events'),
                DB::raw('SUM(capacity) as total_capacity'),
                DB::raw('COUNT(bookings.id) as total_bookings'),
                DB::raw('SUM(CASE WHEN bookings.status = "confirmed" THEN bookings.total_amount ELSE 0 END) as total_revenue')
            )
            ->leftJoin('bookings', 'events.id', '=', 'bookings.event_id')
            ->where('events.status', 'published')
            ->groupBy('venue')
            ->orderByDesc('total_revenue')
            ->get();
        });
    }

    /**
     * Get booking trends over time.
     */
    public function getBookingTrends($period = 'month')
    {
        $dateFormat = $period === 'day' ? '%Y-%m-%d' : ($period === 'week' ? '%Y-%u' : '%Y-%m');

        return Cache::remember('booking_trends_' . $period, 1800, function () use ($dateFormat) {
            return Booking::select(
                DB::raw('DATE_FORMAT(created_at, "' . $dateFormat . '") as period'),
                DB::raw('COUNT(*) as total_bookings'),
                DB::raw('SUM(CASE WHEN status = "confirmed" THEN 1 ELSE 0 END) as confirmed_bookings'),
                DB::raw('SUM(CASE WHEN status = "confirmed" THEN total_amount ELSE 0 END) as revenue')
            )
            ->where('created_at', '>=', now()->subDays(90))
            ->groupBy('period')
            ->orderBy('period')
            ->get();
        });
    }

    /**
     * Bulk cancel bookings for an event.
     */
    public function bulkCancelBookings($eventId, $reason = null)
    {
        return DB::transaction(function () use ($eventId, $reason) {
            $bookings = Booking::where('event_id', $eventId)
                ->where('status', 'confirmed')
                ->get();

            foreach ($bookings as $booking) {
                $booking->update([
                    'status' => 'cancelled',
                    'notes' => ($booking->notes ? $booking->notes . '\n' : '') . 'Cancelled: ' . ($reason ?: 'Event cancelled'),
                ]);
            }

            // Clear caches
            Cache::forget('event_' . $eventId . '_available_tickets');
            Cache::forget('event_occupancy_stats');
            Cache::forget('top_events_30_days');

            return $bookings->count();
        });
    }
}
