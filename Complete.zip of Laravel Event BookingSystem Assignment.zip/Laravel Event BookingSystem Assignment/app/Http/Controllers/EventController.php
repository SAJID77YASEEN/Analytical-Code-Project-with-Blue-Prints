<?php

namespace App\Http\Controllers;

use App\Models\Event;
use App\Models\Booking;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;

class EventController extends Controller
{
    /**
     * Display a listing of events with search, filter, and pagination.
     */
    public function index(Request $request)
    {
        $query = Event::with('user')
            ->where('status', 'published')
            ->upcoming();

        // Search functionality
        if ($request->filled('search')) {
            $query->search($request->search);
        }

        // Filter by venue
        if ($request->filled('venue')) {
            $query->where('venue', 'like', '%' . $request->venue . '%');
        }

        // Filter by date range
        if ($request->filled('date_from')) {
            $query->where('date', '>=', $request->date_from);
        }

        if ($request->filled('date_to')) {
            $query->where('date', '<=', $request->date_to);
        }

        // Filter by price range
        if ($request->filled('price_min')) {
            $query->where('price', '>=', $request->price_min);
        }

        if ($request->filled('price_max')) {
            $query->where('price', '<=', $request->price_max);
        }

        // Filter by availability
        if ($request->filled('available_only') && $request->available_only) {
            $query->available();
        }

        // Sorting
        $sortBy = $request->get('sort_by', 'date');
        $sortDirection = $request->get('sort_direction', 'asc');

        $allowedSorts = ['date', 'title', 'price', 'venue'];
        if (in_array($sortBy, $allowedSorts)) {
            $query->orderBy($sortBy, $sortDirection);
        }

        // Cache the results for 5 minutes
        $cacheKey = 'events_' . md5($request->getQueryString());
        $events = Cache::remember($cacheKey, 300, function () use ($query) {
            return $query->paginate(12);
        });

        // Get popular venues for filter dropdown
        $popularVenues = Cache::remember('popular_venues', 3600, function () {
            return Event::select('venue')
                ->where('status', 'published')
                ->groupBy('venue')
                ->orderByRaw('COUNT(*) DESC')
                ->limit(10)
                ->pluck('venue');
        });

        return view('events.index', compact('events', 'popularVenues'));
    }

    /**
     * Show the form for creating a new event.
     */
    public function create()
    {
        $this->authorize('create', Event::class);

        return view('events.create');
    }

    /**
     * Store a newly created event.
     */
    public function store(Request $request)
    {
        $this->authorize('create', Event::class);

        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'required|string',
            'venue' => 'required|string|max:255',
            'capacity' => 'required|integer|min:1|max:10000',
            'date' => 'required|date|after:today',
            'start_time' => 'required|date_format:H:i',
            'end_time' => 'required|date_format:H:i|after:start_time',
            'price' => 'required|numeric|min:0',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        if ($request->hasFile('image')) {
            $validated['image'] = $request->file('image')->store('events', 'public');
        }

        $validated['user_id'] = Auth::id();

        $event = Event::create($validated);

        // Clear events cache
        Cache::flush();

        return redirect()->route('events.show', $event)
            ->with('success', 'Event created successfully!');
    }

    /**
     * Display the specified event.
     */
    public function show(Event $event)
    {
        $event->load('user', 'bookings.user');

        // Get related events (same venue or similar title)
        $relatedEvents = Event::where('id', '!=', $event->id)
            ->where('status', 'published')
            ->upcoming()
            ->where(function ($query) use ($event) {
                $query->where('venue', $event->venue)
                    ->orWhere('title', 'like', '%' . explode(' ', $event->title)[0] . '%');
            })
            ->limit(4)
            ->get();

        return view('events.show', compact('event', 'relatedEvents'));
    }

    /**
     * Show the form for editing the specified event.
     */
    public function edit(Event $event)
    {
        $this->authorize('update', $event);

        return view('events.edit', compact('event'));
    }

    /**
     * Update the specified event.
     */
    public function update(Request $request, Event $event)
    {
        $this->authorize('update', $event);

        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'required|string',
            'venue' => 'required|string|max:255',
            'capacity' => 'required|integer|min:1|max:10000',
            'date' => 'required|date|after:today',
            'start_time' => 'required|date_format:H:i',
            'end_time' => 'required|date_format:H:i|after:start_time',
            'price' => 'required|numeric|min:0',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        if ($request->hasFile('image')) {
            // Delete old image
            if ($event->image) {
                Storage::disk('public')->delete($event->image);
            }
            $validated['image'] = $request->file('image')->store('events', 'public');
        }

        $event->update($validated);

        // Clear cache
        Cache::flush();

        return redirect()->route('events.show', $event)
            ->with('success', 'Event updated successfully!');
    }

    /**
     * Remove the specified event.
     */
    public function destroy(Event $event)
    {
        $this->authorize('delete', $event);

        // Check if there are confirmed bookings
        if ($event->confirmedBookings()->exists()) {
            return redirect()->back()
                ->with('error', 'Cannot delete event with confirmed bookings.');
        }

        // Delete image
        if ($event->image) {
            Storage::disk('public')->delete($event->image);
        }

        $event->delete();

        // Clear cache
        Cache::flush();

        return redirect()->route('events.index')
            ->with('success', 'Event deleted successfully!');
    }

    /**
     * Get event analytics data.
     */
    public function analytics(Event $event)
    {
        $this->authorize('view', $event);

        $analytics = [
            'total_bookings' => $event->bookings()->count(),
            'confirmed_bookings' => $event->confirmedBookings()->count(),
            'cancelled_bookings' => $event->bookings()->cancelled()->count(),
            'total_revenue' => $event->confirmedBookings()->sum('total_amount'),
            'occupancy_percentage' => $event->occupancy_percentage,
            'available_tickets' => $event->available_tickets,
        ];

        return response()->json($analytics);
    }
}
