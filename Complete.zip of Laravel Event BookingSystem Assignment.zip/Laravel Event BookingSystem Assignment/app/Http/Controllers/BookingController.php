<?php

namespace App\Http\Controllers;

use App\Models\Event;
use App\Models\Booking;
use App\Services\BookingService;
use App\Jobs\SendBookingConfirmation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;

class BookingController extends Controller
{
    protected $bookingService;

    public function __construct(BookingService $bookingService)
    {
        $this->middleware('auth');
        $this->bookingService = $bookingService;
    }

    /**
     * Display a listing of user bookings.
     */
    public function index()
    {
        $bookings = Auth::user()->bookings()
            ->with('event')
            ->orderBy('created_at', 'desc')
            ->paginate(10);

        return view('bookings.index', compact('bookings'));
    }

    /**
     * Show the booking form.
     */
    public function create(Event $event)
    {
        if ($event->isPast()) {
            return redirect()->back()->with('error', 'Cannot book tickets for past events.');
        }

        if ($event->isFullyBooked()) {
            return redirect()->back()->with('error', 'This event is fully booked.');
        }

        return view('bookings.create', compact('event'));
    }

    /**
     * Store a new booking with overbooking prevention.
     */
    public function store(Request $request, Event $event)
    {
        $request->validate([
            'quantity' => 'required|integer|min:1|max:10',
            'notes' => 'nullable|string|max:500',
        ]);

        try {
            // Use database transaction with row locking to prevent overbooking
            $booking = DB::transaction(function () use ($request, $event) {
                // Lock the event row for update to prevent concurrent bookings
                $event = Event::lockForUpdate()->findOrFail($event->id);

                // Check availability after locking
                if ($event->available_tickets < $request->quantity) {
                    throw new \Exception('Not enough tickets available. Only ' . $event->available_tickets . ' tickets left.');
                }

                // Create the booking
                $booking = new Booking([
                    'user_id' => Auth::id(),
                    'event_id' => $event->id,
                    'quantity' => $request->quantity,
                    'total_amount' => $event->price * $request->quantity,
                    'status' => 'confirmed',
                    'notes' => $request->notes,
                    'payment_status' => 'pending',
                ]);

                $booking->save();

                return $booking;
            });

            // Queue email confirmation
            SendBookingConfirmation::dispatch($booking);

            // Clear cache for this event
            Cache::forget('event_' . $event->id . '_available_tickets');

            return redirect()->route('bookings.show', $booking)
                ->with('success', 'Booking confirmed! Confirmation email will be sent shortly.');

        } catch (\Exception $e) {
            return redirect()->back()
                ->with('error', $e->getMessage())
                ->withInput();
        }
    }

    /**
     * Display the specified booking.
     */
    public function show(Booking $booking)
    {
        $this->authorize('view', $booking);

        return view('bookings.show', compact('booking'));
    }

    /**
     * Cancel a booking.
     */
    public function cancel(Booking $booking)
    {
        $this->authorize('update', $booking);

        if (!$booking->canBeCancelled()) {
            return redirect()->back()->with('error', 'This booking cannot be cancelled.');
        }

        DB::transaction(function () use ($booking) {
            $booking->cancel();

            // Clear cache for the event
            Cache::forget('event_' . $booking->event_id . '_available_tickets');
        });

        return redirect()->route('bookings.index')
            ->with('success', 'Booking has been cancelled successfully.');
    }

    /**
     * Get booking statistics for dashboard.
     */
    public function getStats()
    {
        $user = Auth::user();

        $stats = [
            'total_bookings' => $user->bookings()->count(),
            'upcoming_events' => $user->bookings()
                ->whereHas('event', function ($query) {
                    $query->where('date', '>', now());
                })
                ->where('status', 'confirmed')
                ->count(),
            'past_events' => $user->bookings()
                ->whereHas('event', function ($query) {
                    $query->where('date', '<', now());
                })
                ->where('status', 'confirmed')
                ->count(),
            'cancelled_bookings' => $user->bookings()
                ->where('status', 'cancelled')
                ->count(),
        ];

        return response()->json($stats);
    }
}
