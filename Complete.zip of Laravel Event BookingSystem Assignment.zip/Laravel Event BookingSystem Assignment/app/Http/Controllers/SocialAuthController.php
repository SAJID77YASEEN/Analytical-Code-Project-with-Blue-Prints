<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Laravel\Socialite\Facades\Socialite;
use Illuminate\Support\Str;

class SocialAuthController extends Controller
{
    /**
     * Redirect to social provider.
     */
    public function redirect($provider)
    {
        $allowedProviders = ['google', 'github'];

        if (!in_array($provider, $allowedProviders)) {
            return redirect()->route('login')
                ->with('error', 'Invalid social login provider.');
        }

        return Socialite::driver($provider)->redirect();
    }

    /**
     * Handle social provider callback.
     */
    public function callback($provider)
    {
        try {
            $socialUser = Socialite::driver($provider)->user();

            // Check if user already exists with this social provider
            $user = User::where('provider', $provider)
                       ->where('provider_id', $socialUser->getId())
                       ->first();

            if ($user) {
                // Update avatar if needed
                if ($socialUser->getAvatar() && $user->avatar !== $socialUser->getAvatar()) {
                    $user->update(['avatar' => $socialUser->getAvatar()]);
                }

                Auth::login($user);
                return $this->redirectAfterLogin();
            }

            // Check if user exists with the same email
            $existingUser = User::where('email', $socialUser->getEmail())->first();

            if ($existingUser) {
                // Link social account to existing user
                $existingUser->update([
                    'provider' => $provider,
                    'provider_id' => $socialUser->getId(),
                    'avatar' => $socialUser->getAvatar(),
                ]);

                Auth::login($existingUser);
                return $this->redirectAfterLogin();
            }

            // Create new user
            $user = User::create([
                'name' => $socialUser->getName(),
                'email' => $socialUser->getEmail(),
                'email_verified_at' => now(),
                'provider' => $provider,
                'provider_id' => $socialUser->getId(),
                'avatar' => $socialUser->getAvatar(),
                'password' => Hash::make(Str::random(24)), // Random password for social users
            ]);

            Auth::login($user);

            return $this->redirectAfterLogin()
                ->with('success', 'Welcome! Your account has been created successfully.');

        } catch (\Exception $e) {
            return redirect()->route('login')
                ->with('error', 'Unable to login with ' . ucfirst($provider) . '. Please try again.');
        }
    }

    /**
     * Redirect user after successful login.
     */
    private function redirectAfterLogin()
    {
        return redirect()->intended(route('dashboard'));
    }

    /**
     * Unlink social provider from user account.
     */
    public function unlink(Request $request)
    {
        $user = Auth::user();

        // Don't allow unlinking if user doesn't have a password
        if (empty($user->password)) {
            return redirect()->back()
                ->with('error', 'Please set a password before unlinking your social account.');
        }

        $user->update([
            'provider' => null,
            'provider_id' => null,
            'avatar' => null,
        ]);

        return redirect()->back()
            ->with('success', 'Social account has been unlinked successfully.');
    }
}
