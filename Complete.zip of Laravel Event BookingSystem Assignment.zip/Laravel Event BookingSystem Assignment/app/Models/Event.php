<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Event extends Model
{
    use HasFactory, SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'title',
        'description',
        'venue',
        'capacity',
        'date',
        'start_time',
        'end_time',
        'price',
        'image',
        'status',
        'user_id',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'date' => 'datetime',
        'start_time' => 'datetime',
        'end_time' => 'datetime',
        'price' => 'decimal:2',
        'capacity' => 'integer',
    ];

    /**
     * Get the user that owns the event.
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Get all bookings for the event.
     */
    public function bookings()
    {
        return $this->hasMany(Booking::class);
    }

    /**
     * Get confirmed bookings for the event.
     */
    public function confirmedBookings()
    {
        return $this->hasMany(Booking::class)->where('status', 'confirmed');
    }

    /**
     * Get available tickets count.
     */
    public function getAvailableTicketsAttribute()
    {
        return $this->capacity - $this->confirmedBookings()->sum('quantity');
    }

    /**
     * Get occupancy percentage.
     */
    public function getOccupancyPercentageAttribute()
    {
        if ($this->capacity == 0) return 0;

        $booked = $this->confirmedBookings()->sum('quantity');
        return round(($booked / $this->capacity) * 100, 2);
    }

    /**
     * Check if event is fully booked.
     */
    public function isFullyBooked()
    {
        return $this->available_tickets <= 0;
    }

    /**
     * Check if event date has passed.
     */
    public function isPast()
    {
        return $this->date < now();
    }

    /**
     * Scope for upcoming events.
     */
    public function scopeUpcoming($query)
    {
        return $query->where('date', '>', now());
    }

    /**
     * Scope for past events.
     */
    public function scopePast($query)
    {
        return $query->where('date', '<', now());
    }

    /**
     * Scope for events with available tickets.
     */
    public function scopeAvailable($query)
    {
        return $query->whereRaw('capacity > (
            SELECT COALESCE(SUM(quantity), 0) 
            FROM bookings 
            WHERE event_id = events.id 
            AND status = "confirmed"
        )');
    }

    /**
     * Scope for searching events.
     */
    public function scopeSearch($query, $search)
    {
        return $query->where(function ($q) use ($search) {
            $q->where('title', 'like', "%{$search}%")
              ->orWhere('description', 'like', "%{$search}%")
              ->orWhere('venue', 'like', "%{$search}%");
        });
    }
}
